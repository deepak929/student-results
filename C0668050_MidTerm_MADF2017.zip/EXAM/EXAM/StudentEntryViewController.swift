//
//  StudentEntryViewController.swift
//  EXAM
//
//  Created by MacStudent on 2017-10-20.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class StudentEntryViewController: NSObject {

    @IBAction func StudentEntryViewController(_ sender: Any) {
    }
    
    
    @IBAction func Studentid(_ sender: Any) {
    }
    
    
    @IBAction func StudentName(_ sender: Any) {
    }
    
    
    @IBAction func StudentEmailAddress(_ sender: Any) {
    }
    
    
    @IBAction func StudentDateOfBirthDate(_ sender: Any) {
    }
    
    
    @IBAction func Subject1(_ sender: Any) {
    }
    @IBAction func Subject2(_ sender: Any) {
    }
    @IBAction func Subject3(_ sender: Any) {
    }
    @IBAction func Subject4(_ sender: Any) {
    }
    @IBAction func Subject5(_ sender: Any) {
    }
    @IBAction func CalculateResult(_ sender: Any) {
       
           
        
        
       
    }
}
