//
//  StudentResultViewController.swift
//  EXAM
//
//  Created by MacStudent on 2017-10-20.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class StudentResultViewController: NSObject {

}
