//
//  ViewController.swift
//  EXAM
//
//  Created by MacStudent on 2017-10-20.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var UserName: UITextField!
    
    @IBOutlet weak var Password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBOutlet weak var submit: UIButton!
    
    func SubmitClick(_ sender: UIButton) {
        
        if(UserName.text == "admin" && Password.text == "admin@123")
        {
            print("success : ", UserName.text! )
        }
        else{
            print("invalid user id or password")
        }
    }
}

    



